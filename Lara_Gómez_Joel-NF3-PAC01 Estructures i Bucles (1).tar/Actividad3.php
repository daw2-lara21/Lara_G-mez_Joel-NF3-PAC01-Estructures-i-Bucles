<?php
session_start();

$_SESSION['color'] = $_POST['color'];
$_SESSION['fuente'] = $_POST['fuente'];
$_SESSION['tamaño'] = $_POST['tamaño'];
$_SESSION['texto'] = $_POST['texto'];

date_default_timezone_set("Europe/Madrid");

echo "Yesterday it was\t". date("d", strtotime("-1 day"));
echo "<br/>";
echo "The previous month is\t". date("d", strtotime("-1 month"));
echo "<br/>";
$dia_actual = date_create("2020-10-09");
$fin_mes = date_create("2020-10-31");
$diferencia = $dia_actual->diff($fin_mes);

echo "There are\t". $diferencia->format('%R%a days');
echo "left in this month";
echo "<br/>";
$mes_actual = date_create("2020-10-09");
$fin_anyo = date_create("2020-12-31");
$diferenciames = $mes_actual->diff($fin_anyo);
$meses = ($diferenciames->y*12) + $diferenciames->m;
echo "There are\t".  $meses . "\tmonths left in the current year";
echo "<br />";
echo "<br />";
$mesActual = date('m');
 
    // Si estamos entre el 1 de junio y el 31 de septiembre (incluidos)
if ( $mesActual >= '06' && $mesActual <= '09' ) {
    echo "¡Buen verano!";
}else if ( $mesActual >= '09' && $mesActual <= '12'){
    echo "¡Buen otoño!";
}else if( $mesActual >= '12' && $mesActual <= '03'){
    echo "¡Buen invierno!";
}else if ( $mesActual >= '03' && $mesActual <= '06'){
    echo "¡Buena primavera!";
}

$archivo = "contador.txt";
$contador = 0;

$fp = fopen($archivo,"r");
$contador = fgets($fp, 26);
fclose($fp);

$contador = $contador +1;

$fp = fopen($archivo,"w+");
fwrite($fp, $contador, 26);
fclose($fp);

echo "\tEsta página fue visitada $contador veces";


?>

<html>
    <head>
        <style>
             .link{
                margin-top: 110%;
                text-align: center;
            }
            #sitio{
                text-align: center;
            }
        </style>
    </head>
    <body>
        <form method="post" action="Actividad3_1.php">
            <p>Introduce el texto que quieras:
                <input type="text" name="texto"/>
             </p>
            <p>Introduce el color:
                <input type="color" name="color"/>
            </p>
            <p>Introduce la fuente: 
                <input type="text" name="fuente" list="fuentetexto"/>
            </p>
            <p>Introduce el tamaño:
                <input type="range" name="tamaño" min="0" max="1000"/>
            </p>
            <p>
                <input type="submit" name="submit" value="Submit"/>
            </p>
            <p>
                <input type="checkbox" name="checkbox" />
            </p>
        </form>
        <datalist id="fuentetexto"> 
            <option value="Arial">
            <option value="Calibri">
            <option value="Times New Roman">
        </datalist>
        <p class="link"> <a href="mailto:laragomezjoel@fpllefia.com">laragomezjoel@fpllefia.com</a></p>

        <div id="sitio">
            <p>Sitio desarrollado por: Joel Lara Gómez </p>
        </div>
    </body>  
</html>