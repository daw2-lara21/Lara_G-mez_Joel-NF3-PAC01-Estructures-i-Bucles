<html>
    <head></head>
    <body>
        <ol>
	        <li>He aprendido a usar date</li>
	        <li>He recordado usar CSS después de mucho tiempo</li>
            <li>He aprendido los date_create</li>
            <li>He aprendido restas entre dos fechas</li>
            <li>He aprendido el uso del timezone</li>
            <li>He aprendido varias formas de inputs del formulario (Eso de poner por ejemplo el color)</li>
            <li>He aprendido a hacer un contador de visitas</li>
            <li>He aprendido a enlacar correos electrónicos</li>
            <li>He aprendido a usar un datelist, cosa que no sabía ni que existía</li>
            <li>He aprendido los strtotime</li>
        </ol>
        <p>La  calificación del documento esta vez le doy un 5, porque ha sido demasiado rebuscado esta vez (Y el tema del documento en inglés lo hace más difícil), recomiendo indicar qué quieres exactamente en las actividades</p>
        <p>La explicación del profesor daré un 5 a la explicación por la mínima ayuda.No me ha servido mucho porque al final he tenido que hacerlo yo buscando por internet y demás, así que preferiría una explicación más precisa ya sea en los vídeos o en clase.</p>
        <p>Como alumno, estoy algo estresado entre tantas prácticas, pero voy haciendo</p>
        <p>Una mejora sería que en las actividades expliques exactamente lo que se necesite para facilitar el ejercicio, ya que a veces no se entiende y es un agobio</p>
    </body>
</html>