<?php
if(isset($_POST["submit"])){
    $texto = $_POST["texto"];
    $color = $_POST["color"];
    $fuente = $_POST["fuente"];
    $texto = $_POST["tamaño"];
    setcookie("enviotexto", $texto, time() + 30*24*60*60); //guardamos la cookie
    setcookie("enviocolor", $color, time() + 30*24*60*60); //guardamos la cookie
    setcookie("enviofuente", $fuente, time() + 30*24*60*60); //guardamos la cookie
}
echo "Has elegido". $_COOKIE["enviotexto"];
echo "Has elegido". $_COOKIE["enviocolor"];
echo "Has elegido". $_COOKIE["enviofuente"];

?>
<html>
    <head>
        <style>
            .ejercicio4{
                color:<?php echo $_POST['color'];?>;
                font-family:<?php echo $_POST['fuente'];?>;
                font-size:<?php echo $_POST['tamaño'];?>;
            }
        </style>
    </head>
    <body>
        <p class="ejercicio4"><?php echo $_POST['texto'];?></p>
    </body>
</html>